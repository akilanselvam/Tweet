import React from "react";

function LoadingComponent() {
  return (
    <div className="dots-loading">
      <div></div>
    </div>
  );
}

export default LoadingComponent;
